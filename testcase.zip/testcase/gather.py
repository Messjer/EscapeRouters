import csv
import os

writer = csv.writer(open("general.csv", "wb"))

l = ['M', ' N', ' Gap Size', ' Flow', ' Length', ' Time(s)', ' Gap Size', ' Flow', ' Length', ' Time(s)','(cost_DC - cost_NF)/cost_NF','time_NF/time_DC', ' Gap Size', ' Flow', ' Length', ' Time(s)','(cost_RU - cost_NF)/cost_NF','time_NF/time_RU']
writer.writerow(l)

'''l = ['M', ' N', ' Gap Size', ' Flow', ' Length', ' Time(s)']
writer.writerow(l)'''

writer.writerow(["NF", '', '', '', '', '', "DC", '', '','','','',"RU"])

ex1 = "NF/stats"
ex2 = "DC/stats"
ex3 = "RU/stats"

def strinify(l):
    # l is the lin
    l[len(l) - 1] = "%.2E" % float(l[len(l) - 1])

for i in range(5, 75, 5):
    nf = 0.0
    nf2 = 0.0
    line = []
    filename = ex1 + str(i) + "by" + str(i) + ".csv"
    if os.path.exists(filename):
        file = open(filename, "rb")
        reader = csv.reader(file)
        rows = [row for row in reader]
        line = rows[1]
        strinify(line)
        nf = float(line[4])
        nf2 = float(line[5])
    else:
        line = ['', '', '', '', '', '']

    filename = ex2 + str(i) + "by" + str(i) + ".csv"
    if os.path.exists(filename):
        file = open(filename, "rb")
        reader = csv.reader(file)
        rows = [row for row in reader]
        line = line + rows[1][2:]
        strinify(line)
        if nf != 0.0:
            dc = float(line[8])
            line.append("%.2E" % ((dc - nf) / dc))
            dc2 = float(line[9])
            line.append("%.2E" % (nf2 / dc2))
        else:
            line.append(0.0)
            line.append(0.0)
    else:
        line.extend(['', '', '', '', ''])

    filename = ex3 + str(i) + "by" + str(i) + ".csv"
    if os.path.exists(filename):
        file = open(filename, "rb")
        reader = csv.reader(file)
        rows = [row for row in reader]
        line = line + rows[1][2: ]
        strinify(line)
        if nf != 0.0:
            ru = float(line[14])
            line.append("%.2E" % ((ru - nf) / ru))
            ru2 = float(line[15])
            line.append("%.2E" % (nf2 / ru2))
        else:
            line.append(0.0)
            line.append(0.0)

    writer.writerow(line)
