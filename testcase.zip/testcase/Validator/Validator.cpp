#include "../../src/Common/Board.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sys/types.h>
#include <dirent.h>
#include <cstdio>
#include <map>
using namespace std;

bool FindOnePath(int i, int j, Board& b)
{
	int x = i * (b.K + 1), y = j * (b.K + 1), dir = 0;
	bool pflag = true, dflag = true;
	while(pflag && dflag)
	{
		dir = b.table[x][y];
		b.table[x][y] = 0;
		x += b.dy(dir);
		y += b.dx(dir);
		pflag = x > 0 && x <= b.DN && y > 0 && y <= b.DM;
		dflag = dir;
	}
	if(pflag)
	{
		cout << "Error:Point(" << i * (b.K + 1) << ',' << j * (b.K + 1) << ") can't escape..." << endl;
		return false;
	}
	return true;
}

bool JudgeFraction(Board& b)
{
	for(int i = 1; i <= b.DN; ++i)
		for(int j = 1; j<= b.DM; ++j)
			if(b.table[i][j])
			{
				cout << "Error:A fraction at Point(" << i << ',' << j << ")..." << endl;
				return false;
			}
	return true;
}

int main()
{
	map<int, int> NFlog, DClog, RUlog;
	int m, n;
	string dir;
	for(string type :{"NF","DC","RU"})
	{
		dir = "../" + type;
		auto dirp = opendir(dir.c_str());
		dirent * dp;
		while((dp = readdir(dirp)) != NULL)
		{
			string f_Name = dp->d_name;
			int len = dp->d_namlen;
			if (len <= 4) continue;
			string ext = f_Name.substr(len - 4, 4);
			if( ext != ".txt") continue;
			ifstream fin;
			fin.open(dir + "/" + f_Name);
			if(!fin)
			{
				cout << "No such file or directory!" << endl;
				return 1;
			}


			int N, M, K;
			fin >> N >> M >> K;

			// checking large output are time-consuming
			if (N >= 71) continue;
			cout <<"checking output "<< f_Name <<"..." << endl;

			if (type == "NF")
				NFlog[N] = K;
			else if (type == "DC")
				DClog[N] = K;
			else
				RUlog[N] = K;
			Board b(N, M, K);
			for(int i = 1; i <= b.DN; ++i)
				for(int j = 1; j <= b.DM; ++j)
					fin >> b.table[i][j];

			for(int i = 1; i <= b.N; ++i)
				for(int j = 1; j <= b.M; ++j)
					if(!FindOnePath(i, j , b))
					{
						cout << "Test Failed!" << endl;
						return 1;
					}
			if(!JudgeFraction(b))
			{
				cout << "Test Failed!" << endl;
				return 1;
			}
			cout << "Test Passed at type " << type << ",case " <<  f_Name << endl;
			cout <<endl;
		}
		(void)closedir(dirp);
	}
	for (int i = 1; i <= 70; i++) {
		if (NFlog.find(i) != NFlog.end()) {
			int k1 = NFlog[i], k2 = DClog[i], k3 = RUlog[i];
			if (k1 != k2 || k1 != k3) {
				cout <<"Inconsistent gaps! N = " <<i <<" with "<<k1 <<" , " <<k2 <<" , " <<k3 <<endl;
			}
		} else if (DClog.find(i) != DClog.end()) {
			int k2 = DClog[i], k3 = RUlog[i];
			if (k2 != k3) {
				cout <<"Inconsistent gaps! N = " <<i <<" with " <<k2 <<" , " <<k3 <<endl;
			}
		}
	}
	return 0;
}
